const { SlashCommandBuilder } = require('@discordjs/builders');
module.exports = {
    data: new SlashCommandBuilder()
    .setName('platnosci')
    .setDescription('Komenda od płatności'),
        async execute(interaction, client) {
            await interaction.reply({ content: '# 💵 Sposoby płatności to PayPal, PaySafeCard, Przelew na telefon 💵'})
        }
}